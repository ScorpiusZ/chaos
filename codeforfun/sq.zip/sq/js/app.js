App = Ember.Application.create();

// store = DS.Store.create();

App.Router.map(function(){
	this.resource('application');

    this.resource('topics', { path: 'node/:node_id/topics' });

	this.resource('topic' ,{ path: 'topics/:topic_id' } , function(){
		this.resource('replies' , { path: 'replies/:topic_id' } );
	});

});

//获取社区节点列表
App.ApplicationRoute = Ember.Route.extend({
	beforeModel: function(transition){
		console.log(new Date()+"before:"+transition);
	},

	model: function(){
		return App.Node.findAll();
	},

	afterModel: function(nodes,transition){
		console.log(new Date()+"after:"+nodes);
		if(nodes.length>0)
		{
			console.log(new Date()+"afterChange:"+nodes);
		}
	},

	setupController: function(controller,model){
		this._super(controller,model);
		console.log(new Date()+"setupController:"+model);
	}
});


//【路由】获取帖子列表
App.TopicsRoute = Ember.Route.extend({

	model: function(params){
		currentNodeId = params.node_id;//记录当前的社区id
		App.Topic.findNodeById(params.node_id);
		topicsPage = 1;//初始化帖子列表的页数
		return App.Topic.findAll(currentNodeId,currentTopicsFilter);
	},

	afterModel: function(){
		// this.set('node',this.modelFor('application'));
		console.log('node:'+this.modelFor('application'));
	},

	setupController: function(controller,model){
		this._super(controller,model);
		console.log('noded:'+this.modelFor('application'));
	}
});

//【路由】帖子详情
App.TopicRoute = Ember.Route.extend({
	model: function(params){
		    return $.getJSON('http://10.0.1.6/emberjs/topics.php/topics/'+params.topic_id).then(function(data){
			return App.Topic.create(data);
		});
	}
});

//【路由】回复列表
App.RepliesRoute = Ember.Route.extend({
	model: function(params){
		    return $.getJSON('http://10.0.1.6/emberjs/topics.php/topics/'+params.topic_id+'/replies').then(function(data){
			return data.replies;
		});
	}
});

//【控制器】节点列表
App.ApplicationController = Ember.ObjectController.extend({

});

//【控制器】主题列表
App.TopicsController = Ember.ObjectController.extend({

    isFilterNew: true,
    isFilterAll: false,
    isFilterHot: false,
    isFilterMine: false,
    node: null,

	actions:{
		//查看最新、最热等
		filter: function(filter_v){
			App.Topic.findNodeById(currentNodeId);
			this.set('node',currentNode);
			this.set('isFilterNew',filter_v=="new"?true:false);
			this.set('isFilterAll',filter_v=="all"?true:false);
			this.set('isFilterHot',filter_v=="hot"?true:false);
			this.set('isFilterMine',filter_v=="mine"?true:false);

			currentTopicsFilter = filter_v;//当前的filter值改变
			topicsPage = 1;//初始化帖子列表的页数
			this.set('model' , App.Topic.findAll(currentNodeId,filter_v));
		},

		//查看下一页
		page: function(){
			App.Topic.findNodeById(currentNodeId);
			this.set('node',currentNode);
			topicsPage++;//帖子列表数加1
			this.set('model' , App.Topic.findNextPage(this.get('model'),currentNodeId,currentTopicsFilter));
		},

		//喜欢某一个帖子
		likeTopic: function(topic_id){
			 $.ajax({
		        url: "http://10.0.1.6/emberjs/topics.php/topics/"+topic_id+"/like",
		        type: "PUT",
		        crossDomain: true,
		        async: false,
		        dataType: "json",
		        success:function(result){
		            // likeTopicSuccess(topic_id);
		            return true;
		        },
		        error:function(xhr,status,error){
		            alert("顶失败："+status);
		            return false;
		        }
		    });	

			 //FIXME:请求失败的时候就不要更新了
			var models = this.get('model');
			models.forEach(function(t){
				if(t.id == topic_id)
				{
					t.set('liked_count' , t.liked_count+1);
				}
			});
			this.set('model',models);
		},

		//讨厌某一个帖子
		dislikeTopic: function(topic_id){
			 $.ajax({
		        url: "http://10.0.1.6/emberjs/topics.php/topics/"+topic_id+"/dislike",
		        type: "PUT",
		        crossDomain: true,
		        async: false,
		        dataType: "json",
		        success:function(result){
		            // likeTopicSuccess(topic_id);
		        },
		        error:function(xhr,status,error){
		            alert("踩失败："+status);
		        }
		    });	

			 //FIXME:请求失败的时候就不要更新了
			var models = this.get('model');
			models.forEach(function(t){
				if(t.id == topic_id)
				{
					t.set('disliked_count' , t.disliked_count+1);
				}
			});
			this.set('model',models);
		}

	}//End Actions
});


App.TopicController = Ember.ObjectController.extend({

	actions:{
		//喜欢某一个帖子
		likeTopic: function(topic_id){
			 $.ajax({
		        url: "http://10.0.1.6/emberjs/topics.php/topics/"+topic_id+"/like",
		        type: "PUT",
		        crossDomain: true,
		        async: false,
		        dataType: "json",
		        success:function(result){
		            // likeTopicSuccess(topic_id);
		            return true;
		        },
		        error:function(xhr,status,error){
		            alert("顶失败："+status);
		            return false;
		        }
		    });	

			 //FIXME:请求失败的时候就不要更新了
			var m = this.get('model');
			m.set('liked_count' , m.liked_count+1);
			this.set('model',m);
		},

		//讨厌某一个帖子
		dislikeTopic: function(topic_id){
			 $.ajax({
		        url: "http://10.0.1.6/emberjs/topics.php/topics/"+topic_id+"/dislike",
		        type: "PUT",
		        crossDomain: true,
		        async: false,
		        dataType: "json",
		        success:function(result){
		            // likeTopicSuccess(topic_id);
		        },
		        error:function(xhr,status,error){
		            alert("踩失败："+status);
		        }
		    });	

			 //FIXME:请求失败的时候就不要更新了
			var m = this.get('model');
			m.set('disliked_count' , m.disliked_count+1);
			this.set('model',m);
		}
	}
});

//格式化时间，显示 X分钟之前 类似这样的格式
Ember.Handlebars.helper('format-date' , function(date){
	return moment(date).fromNow();
});

//显示文字中的html标签
var showDown = new Showdown.converter();
Ember.Handlebars.helper('format-markdown' , function(input) {
	return new Handlebars.SafeString(showDown.makeHtml(input));
});

//显示表情
var facial = new Facial.expression();
Ember.Handlebars.helper('facial' , function(input) {
	var facialedText = facial.showFacial(input);
	return new Handlebars.SafeString(showDown.makeHtml(facialedText));
});

//类：节点
App.Node = Ember.Object.extend({

});

App.Node.reopenClass({

	findAll: function(){
		if(allNodes && allNodes.length>0)
		{
			return allNodes;
		}
		 var i = 0;
		 $.getJSON('http://10.0.1.6/emberjs/topics.php/nodes').then(function(data){
			 data.nodes.map(function(node){
				var n = App.Node.create(node);
				// var n = store.createRecord(node);
				n.topicsLink = "saxer#/node/"+n.id+"/topics";
				n.iconLink = "images/fresh_article_cate_"+(i%6)+".png";
				// n.set('topicsLink' , "saxer#/node/"+n.id+"/topics");
				// n.set('iconLink' , "images/fresh_article_cate_"+(i%6)+".png");
				i++;
				allNodes.pushObject(n);
			});
		});
		return allNodes;
	}
});

//类：帖子
App.Topic = Ember.Object.extend({

});

App.Topic.reopenClass({

	findAll: function(node_id,filter){
		isTopicsLoading = true;

		var links = [];
		$.getJSON("http://10.0.1.6/emberjs/topics.php/nodes/"+node_id+"/topics?"+
		 	      "page="+topicsPage+"&device_id=00001393578531256&per_page="+topicsPagePer
			      +(filter?("&filter="+filter):"") ).then(function(data){
			data.topics.forEach(function(t){
			 	t.replylink = '#/topics/'+t.id+'/replies/'+t.id;
			 	// t.body = t.body +'<img src="images/d_aini.png">'+t.body;
                links.pushObject(App.Topic.create(t));
            });
		});    

		isTopicsLoading = false;  
	  return links;
	},

	findNextPage: function(origData,node_id,filter){
		isTopicsLoading = true;
		$.getJSON("http://10.0.1.6/emberjs/topics.php/nodes/"+node_id+"/topics?"+
		 	      "page="+topicsPage+"&device_id=00001393578531256&per_page="+topicsPagePer
			      +(filter?("&filter="+filter):"") ).then(function(data){
			data.topics.forEach(function(t){
			 	t.replylink = '#/topics/'+t.id+'/replies/'+t.id;
                origData.pushObject(App.Topic.create(t));
            });
		});
		   
		isTopicsLoading = false;  
	  return origData;
	},

	findNodeById: function(node_id){
		if(!allNodes || allNodes.length<1)
		{
			return null;
		}
		allNodes.forEach(function(node){
			if(node.id==node_id)
			{
				currentNode = node;
			}
		});
	}

});

//所有社区的节点
var allNodes = [];
//记录当前是在哪个社区
var currentNodeId = null;
var currentNode = null;
//记录当前是最新、最热、我的等信息
var currentTopicsFilter = 'new';
//记录当前请求的页数
var topicsPage = 1;
//记录当前请求的每页的数目
var topicsPagePer = 20;
//当前是否在加载帖子列表
var isTopicsLoading = true;